/*
clock.cpp

Clock implementation

(Real simple, I know)
*/
// Clock.cpp
#include "clock.h"

Clock::Clock(int h, int m, int s) : hours(h), minutes(m), seconds(s) {}
