#!/usr/bin/bash
make
./airline_simulation
